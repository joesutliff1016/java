<div class="five"></div>
</div>
<script src="js/my_js.js"></script>

</body>
</html>
<?php
ob_end_flush(); //end output buffering
?>